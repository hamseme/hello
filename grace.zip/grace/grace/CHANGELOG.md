# CHANGELOG.md

## 1.0.0 (Oct 5, 2018)

First release
